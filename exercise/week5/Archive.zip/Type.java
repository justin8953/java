// Define constants for different data type
enum Type {
   INT, STR, FLOAT
};